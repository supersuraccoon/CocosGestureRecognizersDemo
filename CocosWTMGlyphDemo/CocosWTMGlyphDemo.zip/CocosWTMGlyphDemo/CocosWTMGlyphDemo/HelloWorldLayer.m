#import "HelloWorldLayer.h"
#import "AppDelegate.h"

@implementation HelloWorldLayer
@synthesize gestureDetectorView;
@synthesize gestureDetectorLayer;

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
    HelloWorldLayer *layer = [HelloWorldLayer node];
    [scene addChild: layer];
    return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
        CCLabelTTF *infoLabel = [CCLabelTTF labelWithString:@"" fontName:@"Arial" fontSize:22];
        infoLabel.position = ccp(240 ,280);
        [self addChild:infoLabel z:1 tag:999];

        /*
        self.gestureDetectorView = [[WTMGlyphDetectorView alloc] initWithFrame:CGRectMake(0, 0, 480, 320)];
        self.gestureDetectorView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.gestureDetectorView.delegate = self;
        [self.gestureDetectorView loadTemplatesWithNames:@"circle", @"star", @"square", @"triangle", @"V", @"W", nil];
        [[CCDirector sharedDirector].view addSubview:self.gestureDetectorView];
        */
        self.gestureDetectorLayer = [[WTMGlyphDetectorLayer alloc] init];
        self.gestureDetectorLayer.delegate = self;
        [self.gestureDetectorLayer loadTemplatesWithNames:@"circle", @"star", @"square", @"triangle", @"V", @"W", nil];
        [self addChild:gestureDetectorLayer z:1 tag:999];
        
        NSString *glyphNames = [self.gestureDetectorView getGlyphNamesString];
        if ([glyphNames length] > 0) {
            [infoLabel setString:[NSString stringWithFormat:@"Loaded templates:\n%@.\nStart drawing.",
                                  [self.gestureDetectorView getGlyphNamesString]]];
        }
	}
	return self;
}

#pragma mark - Delegate
#define GESTURE_SCORE_THRESHOLD         1.0f
- (void)wtmGlyphDetectorView:(WTMGlyphDetectorView*)theView glyphDetected:(WTMGlyph *)glyph withScore:(float)score
{
    CCLabelTTF *infoLabel = (CCLabelTTF *)[self getChildByTag:999];
    //Reject detection when quality too low
    //More info: http://britg.com/2011/07/17/complex-gesture-recognition-understanding-the-score/
    NSString *statusString = @"";
    if (score < GESTURE_SCORE_THRESHOLD) {
        [infoLabel setString:[statusString stringByAppendingString:@"Reject detection: quality too low"]];
        return;
    }
    NSString *glyphNames = [self.gestureDetectorView getGlyphNamesString];
    if ([glyphNames length] > 0) {
        [infoLabel setString:[statusString stringByAppendingFormat:@"Loaded templates:%@\n\n", glyphNames]];
    }
    [infoLabel setString:[statusString stringByAppendingFormat:@"Last gesture detected: %@\nScore: %.3f", glyph.name, score]];
}

- (void)glyphDetected:(WTMGlyph *)glyph withScore:(float)score
{
    CCLabelTTF *infoLabel = (CCLabelTTF *)[self getChildByTag:999];
    //Reject detection when quality too low
    //More info: http://britg.com/2011/07/17/complex-gesture-recognition-understanding-the-score/
    NSString *statusString = @"";
    if (score < GESTURE_SCORE_THRESHOLD) {
        [infoLabel setString:[statusString stringByAppendingString:@"Reject detection: quality too low"]];
        return;
    }
    NSString *glyphNames = [self.gestureDetectorView getGlyphNamesString];
    if ([glyphNames length] > 0) {
        [infoLabel setString:[statusString stringByAppendingFormat:@"Loaded templates:%@\n\n", glyphNames]];
    }
    [infoLabel setString:[statusString stringByAppendingFormat:@"Last gesture detected: %@\nScore: %.3f", glyph.name, score]];
}


- (void) dealloc
{
    /*
    [self.gestureDetectorView removeFromSuperview];
    self.gestureDetectorView.delegate = nil;
    self.gestureDetectorView = nil;
    */
    self.gestureDetectorLayer.delegate = nil;
    self.gestureDetectorLayer = nil;
	[super dealloc];
}

@end
