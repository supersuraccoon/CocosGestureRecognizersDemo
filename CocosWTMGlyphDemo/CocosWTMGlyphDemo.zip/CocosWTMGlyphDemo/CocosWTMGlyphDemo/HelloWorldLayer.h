#import "cocos2d.h"
#import "WTMGlyphDetectorView.h"
#import "WTMGlyphDetectorLayer.h"

@interface HelloWorldLayer : CCLayer <WTMGlyphDetectorLayerDelegate, WTMGlyphDetectorViewDelegate>
{
    WTMGlyphDetectorView *gestureDetectorView;
    WTMGlyphDetectorLayer *gestureDetectorLayer;
}

+(CCScene *) scene;

@property(nonatomic, retain) WTMGlyphDetectorView *gestureDetectorView;
@property(nonatomic, retain) WTMGlyphDetectorLayer *gestureDetectorLayer;

@end
