#import "WTMGlyphDetectorLayer.h"

@implementation WTMGlyphDetectorLayer
@synthesize delegate;
@synthesize myPathArray;
@synthesize enableDrawing;
@synthesize glyphDetector;
@synthesize glyphNamesArray;

- (id) init
{
    if (self = [super init]) {
        [self initGestureDetector];
        self.enableDrawing = YES;
        self.myPathArray = [[CCArray alloc] init];
        [[CCDirector sharedDirector].touchDispatcher addTargetedDelegate:self priority:0 swallowsTouches:YES];
    }
    return self;
}

- (void) initGestureDetector
{
    self.glyphDetector = [WTMGlyphDetector detector];
    self.glyphDetector.delegate = self;
    self.glyphDetector.timeoutSeconds = 1;
    if (self.glyphNamesArray == nil) self.glyphNamesArray = [[NSMutableArray alloc] init];
}

- (NSString *)getGlyphNamesString
{
    if (self.glyphNamesArray == nil || [self.glyphNamesArray count] <= 0) return @"";
    return [self.glyphNamesArray componentsJoinedByString: @", "];
}

- (void)loadTemplatesWithNames:(NSString*)firstTemplate, ...
{
    va_list args;
    va_start(args, firstTemplate);
    for (NSString *glyphName = firstTemplate; glyphName != nil; glyphName = va_arg(args, id)) {
        if (![glyphName isKindOfClass:[NSString class]]) continue;
        [self.glyphNamesArray addObject:glyphName];
        NSData *jsonData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:glyphName ofType:@"json"]];
        [self.glyphDetector addGlyphFromJSON:jsonData name:glyphName];
    }
    va_end(args);
}

#pragma mark - WTMGlyphDelegate
- (void)glyphDetected:(WTMGlyph *)glyph withScore:(float)score
{
    if ([self.delegate respondsToSelector:@selector(glyphDetected:withScore:)]) [self.delegate glyphDetected:glyph withScore:score];
    [self performSelector:@selector(clearDrawingIfTimeout) withObject:nil afterDelay:1.0f];
}

- (void)glyphResults:(NSArray *)results
{
    //Raw results from the library?
    //Not sure what this delegate function is for, undocumented
}

#pragma mark - Touch events
- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    BOOL hasTimeOut = [self.glyphDetector hasTimedOut];
    if (hasTimeOut) {
        CCLOG(@"Gesture detector reset");
        [self.glyphDetector reset];
        if (self.enableDrawing) [self.myPathArray removeAllObjects];
    }
    CGPoint point = [touch locationInView: [touch view]];
    [self.glyphDetector addPoint:point];
    if (!self.enableDrawing) return YES;
    CGPoint drawPoint = [[CCDirector sharedDirector] convertToGL:point];
    [self.myPathArray addObject:[NSValue valueWithCGPoint:drawPoint]];
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
    CGPoint point = [touch locationInView: [touch view]];
    [self.glyphDetector addPoint:point];
    if (!self.enableDrawing) return;
    CGPoint drawPoint = [[CCDirector sharedDirector] convertToGL:point];
    [self.myPathArray addObject:[NSValue valueWithCGPoint:drawPoint]];
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    CGPoint point = [touch locationInView: [touch view]];
    [self.glyphDetector addPoint:point];
    [self.glyphDetector detectGlyph];
}

#pragma mark - draw
- (void)draw
{
    if (!self.enableDrawing) return;
    if ([self.myPathArray count] <= 1) return;
    //draw
    ccDrawColor4F(255.0f, 0.0f, 0.0f, 255.0f);
    glLineWidth(3.0f);
    CGPoint sPt = [[self.myPathArray objectAtIndex:0] CGPointValue];
    for (int i = 1; i < [self.myPathArray count]; i ++) {
        if (i >= [self.myPathArray count]) break;
        CGPoint ePt = [[self.myPathArray objectAtIndex:i] CGPointValue];
        ccDrawLine(sPt, ePt);
        sPt = ePt;
    }
}

- (void)clearDrawingIfTimeout
{
    if (!self.enableDrawing) return;
    if (![self.glyphDetector hasTimedOut]) return;
    [self.myPathArray removeAllObjects];
}

@end
