#import "cocos2d.h"
#import "WTMGlyphDetector.h"

@protocol WTMGlyphDetectorLayerDelegate <NSObject>
@optional
- (void)glyphDetected:(WTMGlyph *)glyph withScore:(float)score;
@end

@interface WTMGlyphDetectorLayer: CCLayer {
    id delegate;
    BOOL enableDrawing;
    WTMGlyphDetector *glyphDetector;
    NSMutableArray *glyphNamesArray;
    CCArray *myPathArray;
}

- (void) initGestureDetector;
- (void) loadTemplatesWithNames:(NSString*)firstTemplate, ... NS_REQUIRES_NIL_TERMINATION;
- (NSString *) getGlyphNamesString;

@property (nonatomic, retain) id delegate;
@property (nonatomic) BOOL enableDrawing;
@property (nonatomic, retain) WTMGlyphDetector *glyphDetector;
@property (nonatomic, retain) NSMutableArray *glyphNamesArray;
@property (nonatomic, retain) CCArray *myPathArray;

@end
