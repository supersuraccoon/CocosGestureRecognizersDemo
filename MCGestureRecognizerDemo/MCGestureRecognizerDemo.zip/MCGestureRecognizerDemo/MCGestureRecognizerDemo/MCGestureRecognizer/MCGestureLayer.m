#import "MCGestureLayer.h"

@implementation MCGestureLayer

@synthesize enableDrawing;
@synthesize myPathArray;
@synthesize mcAnalyzer;

- (id)init
{
    if (self = [super init]) {
	    self.mcAnalyzer = [[MCGestureAnalyzer alloc] initWithDelegate: self];
		NSString *_fpath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: @"gestures_data.txt"];
		[self.mcAnalyzer addGestureFromFile:_fpath];
        self.enableDrawing = YES;
        self.myPathArray = [[CCArray alloc] init];
        [[CCDirector sharedDirector].touchDispatcher addTargetedDelegate:self priority:0 swallowsTouches:YES];
        
        CCLabelTTF *label = [CCLabelTTF labelWithString:@"MCGestureRecognizer Demo" fontName:@"Marker Felt" fontSize:28];
		CGSize size = [[CCDirector sharedDirector] winSize];
		label.position =  ccp( size.width /2 , size.height/2 );
		[self addChild:label z:1 tag:999];

    }
    return self;
}

- (void) dealloc 
{
	[self.mcAnalyzer release];
	[super dealloc];
}


#pragma mark - Touch events
- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    CGPoint point = [touch locationInView: [touch view]];
    [self.mcAnalyzer clearTouches];
    [self.mcAnalyzer addTouchPoint: point];
    CGPoint drawPoint = [[CCDirector sharedDirector] convertToGL:point];
    [self.myPathArray addObject:[NSValue valueWithCGPoint:drawPoint]];
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event  
{  
    CGPoint point = [touch locationInView: [touch view]];
    [self.mcAnalyzer addTouchPoint: point];
    CGPoint drawPoint = [[CCDirector sharedDirector] convertToGL:point];
    [self.myPathArray addObject:[NSValue valueWithCGPoint:drawPoint]];
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event  
{
    CGPoint point = [touch locationInView: [touch view]];
    [self.mcAnalyzer addTouchPoint: point];
    NSString *gestureMatch = [self.mcAnalyzer bestMatchedGesture];
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:gestureMatch];
    [self.myPathArray removeAllObjects];
}

#pragma mark - draw
- (void)draw
{
    if (!self.enableDrawing) return;
    if ([self.myPathArray count] <= 1) return;
    //draw
    CGPoint sPt = [[self.myPathArray objectAtIndex:0] CGPointValue];
    for (int i = 1; i < [self.myPathArray count]; i ++) {
        if (i >= [self.myPathArray count]) break;
        CGPoint ePt = [[self.myPathArray objectAtIndex:i] CGPointValue];
        ccDrawLine(sPt, ePt);
        sPt = ePt;
    }
}

#pragma mark - delegate
- (void) recognizedGestureWithName:(NSString *) _name score:(CGFloat) _score ratio:(CGFloat) _ratio
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:[NSString stringWithFormat:@"BEST MATCH %@)", _name]];
}

- (void) gestureNotRecognized
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"gestureNotRecognized"];
}

- (void) recognizingGesture
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"recognizingGesture"];
}

- (void) checkForGestureNamed:(NSString *) _name score:(CGFloat) _score
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:[NSString stringWithFormat:@"%@ (score:%0.2f)",_name,_score]];
}

@end
