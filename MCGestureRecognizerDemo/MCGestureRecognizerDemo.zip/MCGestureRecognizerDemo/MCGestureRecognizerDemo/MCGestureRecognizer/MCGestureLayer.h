#import "cocos2d.h"
#import "MCGestureAnalyzer.h"

@interface MCGestureLayer : CCLayer<MCGestureDelegate> {
	BOOL enableDrawing;
	CCArray *myPathArray;
	MCGestureAnalyzer *mcAnalyzer;
}

@property (nonatomic) BOOL enableDrawing;
@property (nonatomic, retain) MCGestureAnalyzer* mcAnalyzer;
@property (nonatomic, retain) CCArray *myPathArray;

@end
