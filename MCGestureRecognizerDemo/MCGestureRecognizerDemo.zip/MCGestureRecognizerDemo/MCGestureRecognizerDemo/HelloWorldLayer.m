#import "HelloWorldLayer.h"
#import "AppDelegate.h"
#import "MCGestureRecognizer/MCGestureLayer.h"
@implementation HelloWorldLayer

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	HelloWorldLayer *layer = [HelloWorldLayer node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
        MCGestureLayer *layer = [[MCGestureLayer alloc] init];
        [self addChild:layer];
    }
	return self;
}

- (void) dealloc
{
	[super dealloc];
}
@end
