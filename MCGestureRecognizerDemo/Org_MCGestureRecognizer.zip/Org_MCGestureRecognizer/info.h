//
//  info.h
//  MCGestureRecognizer
//
//  Created by malcom on 15/08/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface info : UIViewController {

}

- (IBAction) btn_info:(id) sender;

@end
