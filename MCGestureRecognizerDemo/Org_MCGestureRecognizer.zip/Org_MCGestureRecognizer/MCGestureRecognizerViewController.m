//
//  MCGestureRecognizerViewController.m
//  MCGestureRecognizer
//
//  Created by malcom on 14/08/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "MCGestureRecognizerViewController.h"
#import "info.h"

@implementation MCGestureRecognizerViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void) MCGestureDelegate:(MCGestureView *) _view recognizedGestureWithName:(NSString *) _name score:(CGFloat) _score ratio:(CGFloat) _ratio {
	lbl.text = _name;
	log.text = [NSString stringWithFormat:@"%@\n-BEST MATCH '%@' (score:%.2f,ratio:%.2f)",log.text,_name,_score,_ratio];
	if ([log.text length] > 0)
		[log scrollRangeToVisible: NSMakeRange([log.text length]-1, 1)];
}

- (void) MCGestureDelegateRecognizingGesture:(MCGestureView *) _view {
	log.text = @"";

}
- (IBAction) btn_info:(id) sender {
	[self presentModalViewController:[[[info alloc] init] autorelease] animated:YES];
}

/*
- (void) MCGestureDelegate:(MCGestureView *) _view checkForGestureNamed:(NSString *) _name score:(CGFloat) _score {
	log.text = [NSString stringWithFormat:@"%@\n-...'%@' (score:%0.2f)",log.text,_name,_score];
}
*/

- (void)initializeData {
	}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	p_gestureView.p_delegate = self;
	NSString *_fpath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: @"gestures_data.txt"];
	BOOL loaded = [p_gestureView.p_analyzer addGestureFromFile:_fpath];
	if (!loaded) {
		UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Preloaded geomtries not loaded" message:@"Missing file?" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[v show];
		[v release];
	}
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
