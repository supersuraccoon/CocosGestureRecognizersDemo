//
//  MCGestureRecognizerViewController.h
//  MCGestureRecognizer
//
//  Created by malcom on 14/08/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MCGestureCore.h"

@interface MCGestureRecognizerViewController : UIViewController <MCGestureDelegate> {
	IBOutlet MCGestureView *p_gestureView;
	IBOutlet	UILabel *lbl;
	IBOutlet	UITextView *log;

}

- (IBAction) btn_info:(id) sender;

@end

