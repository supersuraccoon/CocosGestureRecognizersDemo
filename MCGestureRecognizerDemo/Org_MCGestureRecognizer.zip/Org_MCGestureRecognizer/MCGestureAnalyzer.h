//
//  MCGestureAnalyzer.h
//  MCGestureRecognizer
//	Original Concept:	The $1 Unistroke Recognizer by Jacob O. Wobbrock,Andrew D. Wilson,Yang Li
//						http://depts.washington.edu/aimgroup/proj/dollar/
//
//  Created by 'malcom' on 14/08/09.
//  Copyright 2009 Daniele Margutti 'malcom'. All rights reserved.
//	Email:	malcom.mac@gmail.com
//	Web:	http://www.malcom-mac.com
//
//	You can use this code in your commercial or opensource project without limitations,
//	but add this statement in your about or credits box:
//	"MCGestureRecognizer by Daniele Margutti - http://www.malcom-mac.com"
//
//	Original Concept: 
//	http://depts.washington.edu/aimgroup/proj/dollar/
//	http://blog.makezine.com/archive/2008/11/gesture_recognition_for_javasc.html

#import <Foundation/Foundation.h>

@class MCPointsContainer;

@protocol MCGestureDelegate
- (void) recognizedGestureWithName:(NSString *) _name score:(CGFloat) _score ratio:(CGFloat) _ratio;
- (void) gestureNotRecognized;
@optional
- (void) checkForGestureNamed:(NSString *) _name score:(CGFloat) _score;
- (void) recognizingGesture;
@end

@interface MCGestureAnalyzer : NSObject {
	BOOL				p_strictlyMatch;
	NSMutableArray		*p_gesturesList;
	MCPointsContainer	*p_touchesContainer;
	MCPointsContainer	*p_endElaboration;
	id<MCGestureDelegate> p_delegate;
}

@property (assign) BOOL p_strictlyMatch;

#pragma mark INIT METHODS
- (id) initWithDelegate:(id) _delegate;

#pragma mark WORKING WITH TOUCHES
- (void) clearTouches;
- (void) addTouches:(NSSet *) _touches;
- (void) addTouchePoint:(CGPoint) point;
- (void) addTouchAtPoint:(CGPoint) point;
- (NSArray *) touches;
- (NSArray *) postElaborationTouches;

#pragma mark CORE
- (NSString*) bestMatchedGesture;
- (NSArray*) gestureTemplates;
- (void) addGesture:(NSDictionary *) _gesture;
- (BOOL) addGestureFromFile:(NSString *) _datapath;

@end
