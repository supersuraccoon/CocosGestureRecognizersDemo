//
//  MCGestureView.m
//  MCGestureRecognizer
//	Original Concept:	The $1 Unistroke Recognizer by Jacob O. Wobbrock,Andrew D. Wilson,Yang Li
//						http://depts.washington.edu/aimgroup/proj/dollar/
//
//  Created by 'malcom' on 14/08/09.
//  Copyright 2009 Daniele Margutti 'malcom'. All rights reserved.
//	Email:	malcom.mac@gmail.com
//	Web:	http://www.malcom-mac.com
//
//	You can use this code in your commercial or opensource project without limitations,
//	but add this statement in your about or credits box:
//	"MCGestureRecognizer by Daniele Margutti - http://www.malcom-mac.com"
//
//	Original Concept: 
//	http://depts.washington.edu/aimgroup/proj/dollar/
//	http://blog.makezine.com/archive/2008/11/gesture_recognition_for_javasc.html

#import "MCGestureView.h"


@implementation MCGestureView

@synthesize p_showUserDraws;
@synthesize p_delegate;
@synthesize p_analyzer;
@synthesize p_showPostElaborationDraws;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
		p_analyzer = [[MCGestureAnalyzer alloc] initWithSourceView: self];
		
		NSString *_fpath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: @"gestures_data.txt"];
		BOOL loaded = [p_analyzer addGestureFromFile:_fpath];
		
		[self _initSettings];
    }
    return self;
}

- (void)awakeFromNib {
	[self _initSettings];
	
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	
    return (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void) dealloc {
	[p_analyzer release];
	[p_delegate release];
	[super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	[p_analyzer clearTouches];
	[p_analyzer addTouches: touches];
	[self setNeedsDisplay];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	[p_analyzer addTouches:touches];
	[self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	[p_analyzer addTouches:touches];
	NSString *gestureMatch = [p_analyzer bestMatchedGesture];
		
	[self setNeedsDisplay];
	
	return gestureMatch;
}

- (void) _initSettings {
	
	p_showUserDraws = YES;
	p_showPostElaborationDraws = NO;
}

@end
