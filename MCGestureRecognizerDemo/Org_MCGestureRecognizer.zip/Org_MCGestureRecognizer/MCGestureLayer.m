#import "MCGestureView.h"

@implementation MCGestureLayer

@synthesize enableDrawing;
@synthesize myPathArray;
@synthesize mcAnalyzer;

- (id)init
{
    if (self = [super init]) {
	    self.mcAnalyzer = [[MCGestureAnalyzer alloc] initWithDelegate: self];
		NSString *_fpath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent: @"gestures_data.txt"];
		BOOL loaded = [p_analyzer addGestureFromFile:_fpath];
        self.enableDrawing = YES;
        self.myPathArray = [[CCArray alloc] init];
        [[CCDirector sharedDirector].touchDispatcher addTargetedDelegate:self priority:0 swallowsTouches:YES];
    }
    return self;
}

- (void) dealloc 
{
	[self.mcAnalyzer release];
	[super dealloc];
}


#pragma mark - Touch events
- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    CGPoint point = [touch locationInView: [touch view]];
    //CGPoint curPosition = [[CCDirector sharedDirector] convertToGL:touchLocation];
    [self.mcAnalyzer clearTouches];
    [self.mcAnalyzer addTouchPoint: point];
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event  
{  
    CGPoint point = [touch locationInView: [touch view]];
    //CGPoint curPosition = [[CCDirector sharedDirector] convertToGL:touchLocation];
    [self.mcAnalyzer addTouchPoint: point];
} 

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event  
{
    CGPoint point = [touch locationInView: [touch view]];
    //CGPoint curPosition = [[CCDirector sharedDirector] convertToGL:touchLocation];
    [self.mcAnalyzer addTouchPoint: point];
    NSString *gestureMatch = [p_analyzer bestMatchedGesture];
    CCLOG(@"%@", gestureMatch);
}

#pragma mark - draw
- (void)draw
{
    if (!self.enableDrawing) return;
    if ([self.myPathArray count] <= 1) return;
    //draw
    CGPoint sPt = [self.myPathArray objectAtIndex:0];
    for (int i = 1; i < [self.myPathArray count]; i ++) {
        if (i >= [self.myPathArray count]) break;
        CGPoint ePt = [self.myPathArray objectAtIndex:i + 1];
        ccDrawLine(sPt, ePt);
        sPt = ePt;
    }
}

#pragma mark - delegate
- (void) recognizedGestureWithName:(NSString *) _name score:(CGFloat) _score ratio:(CGFloat) _ratio
{
    CCLOG(@"%@", [NSString stringWithFormat:@"%@\n-BEST MATCH '%@' (score:%.2f,ratio:%.2f)",log.text,_name,_score,_ratio];);
}

- (void) gestureNotRecognized
{
    CCLOG(@"gestureNotRecognized");
}

- (void) recognizingGesture
{
     CCLOG(@"recognizingGesture");
}

- (void) checkForGestureNamed:(NSString *) _name score:(CGFloat) _score
{
    CCLOG(@"%@", [NSString stringWithFormat:@"%@ (score:%0.2f)",_name,_score]);
}

@end
