//
//  IntroLayer.h
//  GestureDetectionDemo
//
//  Created by SuperSuRaccoon on 12-11-13.
//  Copyright SuperSuRaccoon 2012年. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface IntroLayer : CCLayer
{
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
