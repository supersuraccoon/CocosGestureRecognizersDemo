#import "cocos2d.h"
#import "Gestures.h"

@interface HelloWorldLayer : CCLayer <GestureComplete>
{
}

+(CCScene *) scene;
@end
