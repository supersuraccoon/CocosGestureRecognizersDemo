#import "HelloWorldLayer.h"
#import "AppDelegate.h"

@implementation HelloWorldLayer

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	HelloWorldLayer *layer = [HelloWorldLayer node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Gestures Demo" fontName:@"Marker Felt" fontSize:32];
		CGSize size = [[CCDirector sharedDirector] winSize];
		label.position = ccp( size.width /2 , size.height/2 );
        [self addChild:label z:1 tag:999];
        
        self.isTouchEnabled = YES;
        [Gestures sharedGestures].delegate = self;
		[[Gestures sharedGestures] configure:YES checkSquare:YES checkX:YES checkSwipes:NO resetLimit:10];
		[Gestures sharedGestures].swipeTolerance = 20;
		
    }
	return self;
}

-(void) registerWithTouchDispatcher
{
	[[CCDirector sharedDirector].touchDispatcher addTargetedDelegate:self priority:kCCMenuHandlerPriority swallowsTouches:YES];
}

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    [[Gestures sharedGestures] reset];
	return YES;
}

-(void) ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
    CGPoint point = [touch locationInView: [touch view]];
	CGPoint converted = [[CCDirector sharedDirector] convertToGL:point];
	[[Gestures sharedGestures] addPoint:converted];
}

-(void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    [[Gestures sharedGestures] reset];
}

-(void) circleComplete:(CGCircle) circle
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"circleComplete"];
}
-(void) xComplete:(CGX) x
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"xComplete"];
}
-(void) squareComplete:(CGSquare) square
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"squareComplete"];
}
-(void) swipeLeftComplete
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"swipeLeftComplete"];
}
-(void) swipeRightComplete
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"swipeRightComplete"];
}
-(void) swipeUpComplete
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"swipeUpComplete"];
}
-(void) swipeDownComplete
{
    CCLabelTTF *label = (CCLabelTTF *)[self getChildByTag:999];
    [label setString:@"swipeDownComplete"];
}

- (void) dealloc
{
	[super dealloc];
}
@end
