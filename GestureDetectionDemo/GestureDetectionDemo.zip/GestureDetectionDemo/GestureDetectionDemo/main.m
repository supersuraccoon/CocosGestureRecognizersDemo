//
//  main.m
//  GestureDetectionDemo
//
//  Created by SuperSuRaccoon on 12-11-13.
//  Copyright SuperSuRaccoon 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
